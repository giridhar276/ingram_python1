try:
    ## if mode is not been modified.. the default is r
    fobj = open('customers111111.txt','r')   
    for line in fobj:
        line = line.strip()
        print(line)   
    fobj.close()   
    ## logic2
    val = int(input('Enter any value:'))
    print('you entered :', val)
    
except FileNotFoundError as error:
    print("File not found error")
    print('system defined err message :',error)
except TypeError  as error:
    print("Invalid input")
    print('system defined err message :',error)
except ValueError as error:
    print('Invalid operation')
    print('system defined err message :',error)
except Exception as error:
    print('Unknown exception found')
    print('system defined err message :',error)