

import time

filename = time.strftime("%d_%a_%Y.log")

fobj = open(filename,"w")
fobj.close()


### another method
import pathlib
pathlib.Path(filename).touch()