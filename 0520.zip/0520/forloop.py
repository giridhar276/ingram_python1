
## using for loop
for val in range(1,10):
    print(val)
    
    
    
## using while loop
i = 1
while i <=10 :
    print(i)
    i = i + 1