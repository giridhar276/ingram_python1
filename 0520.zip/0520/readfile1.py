
import matplotlib.pyplot as plt
price = []
sqtfeet = []
fobj = open('realestate.csv')
lne = fobj.readline()
for line in fobj:
    
    line = line.strip()
    output= line.split(',')
    price.append(output[9])
    sqtfeet.append(output[6])
    
    
fobj.close()
plt.plot(price,sqtfeet)
plt.savefig('graph.jpg')
plt.show()
#print(data)