import pymysql

try:
    db = pymysql.connect(host ='localhost',port = 3306 , user= 'root',password ='giridhar')
    
    cursor = db.cursor()
    
    query = 'create database ingram_customers'
    
    cursor.execute(query)

except Exception as error:
    print('database error occured')
    print('System error :', error)
    
else:
    print('database created successfully')
    db.close()


 
