
import os
from openpyxl import Workbook
wb = Workbook()

# grab the active worksheet
ws = wb.active
 
for file in os.listdir():
    ws.append([file])
 

# Save the file
wb.save("sample.xlsx")