
adict = {'chap1':10 ,'chap2':20}

for key in adict:
    print('key :',key)
    print('value :',adict[key])
    
