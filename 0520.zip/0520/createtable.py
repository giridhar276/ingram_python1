import pymysql

try:
    db = pymysql.connect(host ='localhost',port = 3306 , user= 'root',password ='giridhar',database='ingram_customers')
    
    cursor = db.cursor()
    
    query = 'create table realestate (street varchar(200) , city varchar(200) )'
    
    cursor.execute(query)

except Exception as error:
    print('database error occured')
    print('System error :', error)
    
else:
    print('table created successfully')
    db.close()
