

adict = {'chap1':10 ,'chap2':20  , 'chap3':30 }

print(adict)

## adding key-value to the dictionary

adict['chap4'] = 40

print("After adding :", adict)

adict['chap5'] = 50

print("After adding :", adict)

adict['chap6'] = 60

print("After adding :", adict)

# dictionary keys
print("keys  :", adict.keys())

# dictionary values
print("Values  :", adict.values())

## key-value pairs
print("pairs :", adict.items())




