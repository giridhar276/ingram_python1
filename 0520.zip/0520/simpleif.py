
a = 10
b = 20
if a < b :
    print('Inside if')
    print("A is smaller")

