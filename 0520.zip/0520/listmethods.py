
alist = [100,2,300,40]
alist.append(10)
   alist.append(60)
alist.append(10)
# will erase everything from list
#alist.clear()
# get the count of 10 in the list
getcount = alist.count()
print(getcount)

# adding multiple elements
alist.extend([50,10,1,45543,4343,40])
print(alist)
# insert(where,what)
alist.insert(0,1)
print("AFter inserting :", alist)
# remove last element by default
removed = alist.pop()
print("Removed element is :",removed)
## reverse all the elements
alist.reverse()
print(alist)

# sorting - ascending order
alist.sort()
print(alist)
# sorting from big to small
alist.sort(reverse = True)
print(alist)


# remove the element directly
alist.remove(10)
print("After removing ;" , alist)


