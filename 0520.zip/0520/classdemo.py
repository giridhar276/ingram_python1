
## class contains all the common properties
## class is the blueprint of the program
## object is called instance of the class
## self is instance of the object

class Employee:
    def getName(self,language):
        print('I am learning ' + language)


emp1 = Employee()
emp2 = Employee()
emp3 = Employee()
emp1.getName('Python')
emp2.getName('Hadoop')
emp3.getName('scala')