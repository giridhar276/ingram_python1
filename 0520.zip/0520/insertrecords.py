import pymysql

try:
    db = pymysql.connect(host ='localhost',port = 3306 , user= 'root',password ='giridhar',database='ingram_customers')
    
    cursor = db.cursor()
    
    #query = "insert into realestate values('{}','{}')".format('3526 HIGH ST','SACRAMENTO')
    query = 'select * from realestate'
    
    with open('backup.csv','w') as fobj:
        cursor.execute(query)
        for record in cursor.fetchall():
            line = ','.join(record)
            print(line)
            fobj.write(line + "\n")
        
        

    #db.commit()
except Exception as error:
    print('database error occured')
    print('System error :', error)
    
else:
    print('record inserted successfully')
    db.close()
