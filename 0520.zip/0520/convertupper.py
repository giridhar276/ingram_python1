




def changecase(string):
    return string.upper()


getupper = changecase('python')


#########################################
# lambda
#########################################

changecase = lambda name : name.upper()


getupper = changecase('python')
