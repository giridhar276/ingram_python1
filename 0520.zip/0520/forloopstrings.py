
name = 'python'
for char in name :
    print(char)
