


#########################################
# lambda
#########################################

def add(first,second):
    return first + second


getsum = add(10,20)
print(getsum)

#########################################
# lambda
#########################################


add = lambda x , y : x + y

getsum = add(10,20)
print(getsum)
