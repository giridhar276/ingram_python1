
## __init__ is called as constructor
## __init__ stands from initialize

class Employee:
    def __init__(self,language):
        ## creating local variable for the method
        self.language = language
        print('I am learning ' + self.language)


emp1 = Employee('Python')
emp2 = Employee('Hadoop')
emp3 = Employee('scala')
 
