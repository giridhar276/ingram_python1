alist = [10,20,30]

for val in alist:
    print(val)
