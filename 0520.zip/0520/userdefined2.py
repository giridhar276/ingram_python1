

#fixed arguments

def display(lang1,lang2):
    print(lang1,lang2)

display('python','perl')


