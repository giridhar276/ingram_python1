

fobj = open('realestate.csv')
aset = set()
for line in fobj:
    line = line.strip()
    data = line.split(',')

    aset.add(data[1])
 
    
fobj.close()

for city in aset:
    print(city)