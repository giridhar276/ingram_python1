

name = 'python programming'

print(name)
print(name.capitalize())
print(name.upper())
print(name)
print(name[0])

#name[0] = 'm'

print("After modifying :", name)

output = name.split(" ")
print("elements are  :",output)

print("Original string :", name)
print("After replacing :",name.replace('python','unix'))

aname  = 'python    '
print(aname.strip())

print(name.startswith('z'))
print(name.startswith('p'))
print(name.endswith('t'))
print(name.endswith('g'))

print(name.isalpha())
print(name.isalnum())
print(name.isdigit())
print(name.isupper())

print(name.count('p'))

# name[start:stop:step]
print(name)
print(name[0])
print(name[0:5])
print(name[4:7])
print(name[:9])
print(name[::])
print(name[0:15:2])
print(name[0:15:4])
print(name[::5])
print(name[::-1])


## search inside string

# will return the count of the instances
print(name.count("ruby"))

## if the string is existing.. will return starting index
## if the string is not existing. will return -1
print(name.find("eepro"))






string = "I love {} and {}"

print(string.format("unix","java"))

print(string.format(1,2))

print(string.format("unix","oracle"))





































