#default   arguments

def display(lang1= 0,lang2 = 0,lang3 = 0):
    print(lang1,lang2,lang3)

display()
display('python')
display('python','perl')
display('python','perl','oracle')
