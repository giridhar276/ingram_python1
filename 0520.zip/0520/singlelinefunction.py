






def increment(val):
    return val + 1


value = increment(10)
print(value)


#########################################
# lambda
#########################################

increment = lambda x : x + 1

value = increment(10)
print(value)
