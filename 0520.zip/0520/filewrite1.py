


fobj = open('customers.txt' , 'a')

fobj.write('python programming\n')
fobj.write('hadoop administration\n')

fobj.close()

