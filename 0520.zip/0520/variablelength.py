
## variable length arguments

def display(*values):
    print(values)


display(10,20,30,40 ,345,45,45,4,4,3,54,544,34,34,35,46,5,65,4,343,43,43)


###########################################################
def display():
    print('Inside function')


display()
