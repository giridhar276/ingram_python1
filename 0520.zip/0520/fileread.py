
## normal approach
fobj = open('realestate1.csv','w')
fobj.write('US')
fobj.close()


## context manager
with open('realestate2.csv','w') as fobj:
    fobj.write('US')
    
    
## context manager with read
with open('realestate.csv','r') as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
