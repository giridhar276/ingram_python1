class Employee:
    def __init__(self,language):
        print('I am learning ' + language)


emp1 = Employee('Python')
emp2 = Employee('Hadoop')
emp3 = Employee('scala')
 
