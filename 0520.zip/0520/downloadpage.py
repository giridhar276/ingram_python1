from urllib.request import urlretrieve
from bs4 import BeautifulSoup

#file = urlretrieve("https://www.google.com/","google.html")
#
#fobj = open("google.html","r")
#data = fobj.read()  ## read the file in string object
#fobj.close()
#
#soup = BeautifulSoup(data, 'html.parser')
#
#for link in soup.find_all('a'):
#    print(link.get('href'))



from urllib.request import urlretrieve
from bs4 import BeautifulSoup

file = urlretrieve("https://www.google.com/","google.html")

soup = BeautifulSoup(open("google.html","r").read(), 'html.parser')

for link in soup.find_all('a'):
    print(link.get('href'))
    
    
    
    