alist = ['google','linkedin','facebook']

for item in alist:
    url = 'http://' + item + '.com'
    print(url)
    
    
 
alist = ['google','http://linkedin','facebook']

for item in alist:
    if not item.startswith('http://'):
            url = 'http://' + item + '.com'
            print(url)
    
alist = ['google','http://linkedin','facebook']

for item in alist:
    if not 'http://' in item :
            url = 'http://' + item + '.com'
            print(url)    