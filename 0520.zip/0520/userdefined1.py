alist = [10,20,30,40]

blist = []
for val in alist:
    blist.append(val + 5)   
print(blist)



## using map()
def increment(x):
    return x + 5
print(list(map(increment,alist)))


### using map + lambda
print(list(map(lambda x : x + 1 , alist)))




alist = ['10','20','30','40']
print(list(map(int, alist)))


