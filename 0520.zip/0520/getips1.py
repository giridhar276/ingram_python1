

ip = '172.168.'

for val in range(0,2):
    ipadd  = ip +str(val)
    for val in range(1,11):
        ipaddress = ipadd + '.' + str(val)
        print(ipaddress)