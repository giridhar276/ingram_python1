







if __name__ == "__main__":
    print("Program beings from here")
    
    display1()
    display2()
    display3()