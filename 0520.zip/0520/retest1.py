import re



with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        #print(line)
        if re.search('.yt*hon|perl|unix',line):
            print(line)






            
#### re.sub()
##with open('languages.txt','r') as fobj:
##    for line in fobj:
##        line = line.strip()
##        #print(line)
##        line = re.sub('python','spark',line)
##        print(line)
